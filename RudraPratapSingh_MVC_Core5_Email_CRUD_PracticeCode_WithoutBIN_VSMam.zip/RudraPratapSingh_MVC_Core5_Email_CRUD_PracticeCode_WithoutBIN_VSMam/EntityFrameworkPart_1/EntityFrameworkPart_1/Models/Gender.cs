﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace EntityFrameworkPart_1.Models
{
    [Table("tblGender")]
    public class Gender
    {
        [Key]
        public int Gid { get; set; }
        public string Gname { get; set; }
    }
}
