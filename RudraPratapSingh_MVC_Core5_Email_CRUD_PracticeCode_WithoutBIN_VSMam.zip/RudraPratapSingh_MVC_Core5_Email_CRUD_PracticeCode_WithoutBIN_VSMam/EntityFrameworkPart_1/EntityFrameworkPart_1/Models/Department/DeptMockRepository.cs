﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EntityFrameworkPart_1.Models.Department
{
    public class DeptMockRepository : IGenericRepository<Dept>
    {
        private readonly List<Dept> deptList = null;
        public DeptMockRepository()
        {
            deptList = new List<Dept>()
            {
                new Dept(){ Deptno=1, Dname="TestDept1",Location="TestLocation1"},
                new Dept(){ Deptno=2, Dname="TestDept2",Location="TestLocation2"},
                new Dept(){ Deptno=3, Dname="TestDept3",Location="TestLocation3"},
                new Dept(){ Deptno=4, Dname="TestDept4",Location="TestLocation4"}
            };
        }
        public void Add(Dept newrec)
        {
            deptList.Add(newrec);
        }

        public void Delete(int id)
        {
            var deleterec = deptList.Where(s => s.Deptno == id).FirstOrDefault();
            deptList.Remove(deleterec);
        }

        public IEnumerable<Dept> GetAll()
        {
            return deptList;
        }

        public Dept GetById(int id)
        {
            throw new NotImplementedException();
        }

        public void Update(Dept newrec)
        {
            throw new NotImplementedException();
        }
    }
}
