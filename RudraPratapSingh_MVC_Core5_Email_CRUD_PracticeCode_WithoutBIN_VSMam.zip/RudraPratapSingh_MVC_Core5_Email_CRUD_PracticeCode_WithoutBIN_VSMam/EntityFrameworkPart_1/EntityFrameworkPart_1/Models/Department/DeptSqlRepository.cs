﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EntityFrameworkPart_1.Models.Department
{
    public class DeptSqlRepository : IGenericRepository<Dept>
    {
        private readonly AppDbContext context;
        public DeptSqlRepository(AppDbContext context)
        {
            this.context = context;
        }
        public void Add(Dept newrec)
        {
            context.Dept.Add(newrec);
            context.SaveChanges();
        }

        public void Delete(int id)
        {
            var data = context.Dept.Where(s => s.Deptno == id).FirstOrDefault();
            context.Dept.Remove(data);
            context.SaveChanges();
        }

        public IEnumerable<Dept> GetAll()
        {
            return context.Dept.ToList();
        }

        public Dept GetById(int id)
        {
            return context.Dept.Where(s => s.Deptno == id).FirstOrDefault(); 
        }

        public void Update(Dept newrec)
        {
            var olddata = context.Dept.Where(s => s.Deptno == newrec.Deptno).FirstOrDefault();
            olddata.Dname = newrec.Dname;
            olddata.Location = newrec.Location;
            context.SaveChanges();
        }
    }
}
