﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EntityFrameworkPart_1.Models
{
    //public class AppDbContext: DbContext // without Identity
    public class AppDbContext : IdentityDbContext // WIth Identity
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }
        public DbSet<Dept> Dept { get; set; }
        public DbSet<Gender> Gender { get; set; }
        public DbSet<Employee> Employee { get; set; }
        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    modelBuilder.Entity<Gender>().HasData(
        //        new Gender() { Gid=1,Gname="Male"},
        //        new Gender() { Gid = 1, Gname = "Female" }
        //        );
        //}
    }
}
