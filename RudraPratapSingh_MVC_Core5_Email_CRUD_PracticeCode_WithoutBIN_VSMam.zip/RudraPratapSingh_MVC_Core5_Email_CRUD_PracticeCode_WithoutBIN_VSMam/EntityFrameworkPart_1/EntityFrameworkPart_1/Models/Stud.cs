﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EntityFrameworkPart_1.Models
{
    public class Stud
    {
        [Key]
        [Required]
        public int Sid { get; set; }

        [Required]
        public string Sname { get; set; }
    }
}
