﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace EntityFrameworkPart_1.Models
{
    [Table("Employee")]
    public class Employee
    {
        [Key]
        [Required]
        public int Eid { get; set; }

        [StringLength(100)]
        [Required]
        public string Ename { get; set; }

        [Required]
        public int Salary { get; set; }
        [Required]
        public int Deptno { get; set; }

        [StringLength(50)]
        [Required]
        public string Role { get; set; }
        [Required]
        public int Gender { get; set; }
        //public List<Dept> LstDepartments {get; set;}
    }
}
