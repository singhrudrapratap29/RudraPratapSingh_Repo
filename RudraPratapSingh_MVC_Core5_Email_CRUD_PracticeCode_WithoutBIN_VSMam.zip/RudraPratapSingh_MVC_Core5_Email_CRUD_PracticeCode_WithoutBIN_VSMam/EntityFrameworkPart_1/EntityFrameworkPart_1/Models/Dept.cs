﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace EntityFrameworkPart_1.Models
{
    [Table("tblDept")]
    public class Dept
    {
        [Key]
        [Required]
        public int Deptno { get; set; }
        [StringLength(50)]
        [Required]
        public string Dname { get; set; }
        [StringLength(50)]
        [Required]
        public string Location { get; set; }
    }
}
