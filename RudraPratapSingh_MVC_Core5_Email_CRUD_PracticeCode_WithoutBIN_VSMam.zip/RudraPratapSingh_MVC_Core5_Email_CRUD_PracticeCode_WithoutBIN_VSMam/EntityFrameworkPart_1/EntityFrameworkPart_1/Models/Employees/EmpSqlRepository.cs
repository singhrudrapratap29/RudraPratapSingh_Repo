﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EntityFrameworkPart_1.Models.Employees
{
    public class EmpSqlRepository : IGenericRepository<Employee>
    {
        private readonly AppDbContext context;
        public EmpSqlRepository(AppDbContext context)
        {
            this.context = context;
        }
        public void Add(Employee newrec)
        {
            context.Employee.Add(newrec);
            context.SaveChanges();
        }

        public void Delete(int id)
        {
            var data = context.Employee.Where(e => e.Eid == id).FirstOrDefault();
            context.Employee.Remove(data);
            context.SaveChanges();
        }

        public IEnumerable<Employee> GetAll()
        {
            return context.Employee.ToList();
        }

        public Employee GetById(int id)
        {
            return context.Employee.Where(s => s.Eid == id).FirstOrDefault();
        }

        public void Update(Employee newrec)
        {
            var olddata = context.Employee.Where(s => s.Eid == newrec.Eid).FirstOrDefault();
            olddata.Ename = newrec.Ename;
            olddata.Salary = newrec.Salary;
            olddata.Deptno = newrec.Deptno;
            olddata.Role = newrec.Role;
            olddata.Gender = newrec.Gender;
            context.SaveChanges();
        }
    }
}
