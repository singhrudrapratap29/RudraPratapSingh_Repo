﻿using EntityFrameworkPart_1.Email;
using EntityFrameworkPart_1.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EntityFrameworkPart_1.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<IdentityUser> _user;
        private readonly SignInManager<IdentityUser> _signin;
        public AccountController(UserManager<IdentityUser> user, SignInManager<IdentityUser> signin)
        {
            _user = user;
            _signin = signin;
        }
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(RegisterModel registerData)
        {
            if (ModelState.IsValid)
            {
                var user = new IdentityUser
                {
                    UserName = registerData.Email,
                    Email = registerData.Email
                };
                var res = await _user.CreateAsync(user,registerData.Password);
                if (res.Succeeded)
                {
                    await _signin.SignInAsync(user,isPersistent:false); // creates a session cookie
                    return RedirectToAction("Index","Department");
                }
                else
                {
                    foreach (var item in res.Errors)
                    {
                        ModelState.AddModelError(string.Empty, item.Description);
                    }
                }

            }
            return View(registerData);
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Login(LoginModel loginData)
        {
            if (ModelState.IsValid)
            {
                var res = await _signin.PasswordSignInAsync(loginData.Email, loginData.Password, false, false);
                if (res.Succeeded)
                {
                    return RedirectToAction("Index","Dashboard");
                }
                ModelState.AddModelError("","Login Failed");
            }
            return View(loginData);
        }
        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await _signin.SignOutAsync();
            return RedirectToAction("Index", "Dashboard");
        }

        [AllowAnonymous]
        public IActionResult ForgotPassword()
        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> ForgotPassword([Required] string email)
        {
            if (!ModelState.IsValid)
                return View(email);

            var user = await _user.FindByEmailAsync(email);
            if (user == null)
                return RedirectToAction(nameof(ForgotPasswordConfirmation));

            var token = await _user.GeneratePasswordResetTokenAsync(user);
            var link = Url.Action("ResetPassword", "Account", new { token, email = user.Email }, Request.Scheme);

            EmailHelper emailHelper = new EmailHelper();
            bool emailResponse = emailHelper.SendEmailPasswordReset(user.Email, link);

            if (emailResponse)
                return RedirectToAction("ForgotPasswordConfirmation");
            else
            {
                // log email failed 
            }
            return View(email);
        }

        [AllowAnonymous]
        public IActionResult ForgotPasswordConfirmation()
        {
            return View();
        }
        [AllowAnonymous]
        public IActionResult ResetPassword(string token, string email)
        {
            var model = new ResetPassword { Token = token, Email = email };
            return View(model);
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> ResetPassword(ResetPassword resetPassword)
        {
            if (!ModelState.IsValid)
                return View(resetPassword);

            var user = await _user.FindByEmailAsync(resetPassword.Email);
            if (user == null)
                RedirectToAction("ResetPasswordConfirmation");

            var resetPassResult = await _user.ResetPasswordAsync(user, resetPassword.Token, resetPassword.Password);
            if (!resetPassResult.Succeeded)
            {
                foreach (var error in resetPassResult.Errors)
                    ModelState.AddModelError(error.Code, error.Description);
                return View();
            }

            return RedirectToAction("ResetPasswordConfirmation");
        }

        public IActionResult ResetPasswordConfirmation()
        {
            return View();
        }
    }
}
